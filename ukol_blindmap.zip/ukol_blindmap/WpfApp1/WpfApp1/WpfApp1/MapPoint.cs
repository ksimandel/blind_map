﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WpfApp1
{
    public class MapPoint
    {
        public string Name { get; set; }
        public double XPercent { get; set; }
        public double YPercent { get; set; }


        public MapPoint(string name, double xprecent, double ypercent)
        {
            Name = name;
            XPercent = xprecent;
            YPercent = ypercent;
        }
    }
}
