﻿
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;

namespace zaznamnik_skautskych_schuzek
{

    public partial class Nova_schuzka : Window
    {
      
        private readonly Dictionary<string, List<string>> groupChildCounts = new()
        {
            { "Zubři", new List<string> { "Filip Č.", "Kýťa", "Adam", "Honza", "Lukáš", "Andy" } },
            { "Netopýři", new List<string> { "Jirka", "Petr", "Marek" } },
            { "Sojky", new List<string> { "Anna", "Eliška", "Tereza", "Lucie", "Veronika" } }
        };

        public Nova_schuzka()
        {
            InitializeComponent();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            if (druzina.SelectedItem is ComboBoxItem selectedItem)
            {
                string value = selectedItem.Content as string ?? string.Empty;

               
                switch (value)
                {
                    case "Zubři":
                        vedouci1.Content = "Tomek";
                        vedouci2.Content = "Kipi";
                        vedouci3.Content = "Hanus";
                        vedouci4.Content = "Tom Bouda";
                        break;
                    case "Netopýři":
                        vedouci1.Content = "Jáchym";
                        vedouci2.Content = "Karel";
                        vedouci3.Content = "David";
                        vedouci4.Content = "Jeremy";
                        break;
                    case "Sojky":
                        vedouci1.Content = "Klára";
                        vedouci2.Content = "Lucka";
                        vedouci3.Content = "Monča";
                        vedouci4.Content = "Terka";
                        break;
                    default:
                        vedouci1.Content = "Vedoucí";
                        vedouci2.Content = "Vedoucí";
                        vedouci3.Content = "Vedoucí";
                        vedouci4.Content = "Vedoucí";
                        break;
                }

              
                if (groupChildCounts.TryGetValue(value, out var children))
                {
                    PopulateChildren(children);
                }
                else
                {
                    PopulateChildren(new List<string>());
                }
            }
        }

        
        private void PopulateChildren(List<string> children)
        {
         
            detiPanel.Children.Clear();

            foreach (var child in children)
            {
                var cb = new CheckBox
                {
                    Content = child,
                    Margin = new Thickness(0, 0, 0, 4)
                };
                cb.Checked += CheckBox_Checked;
                detiPanel.Children.Add(cb);
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
